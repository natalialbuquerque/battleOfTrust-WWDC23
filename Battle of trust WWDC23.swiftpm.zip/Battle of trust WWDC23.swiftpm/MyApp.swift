//
//  Music.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 18/04/23.
//

import Foundation
import AVFoundation
import SwiftUI

@main
struct MyApp: App {
    
    init() {
        
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
