//
//  EndView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 14/04/23.
//

import SwiftUI

struct EndView: View {
    
    @State private var isShowingAboutBattleOfTrust = false
    @State var isAnimated = false
    @State private var offset = CGSize.zero
    
    var body: some View {
        GeometryReader { geometry in
            
            ZStack{
                Image("BackgroundPlayView")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                
                Text("Wow! That's a price equilibrium!")
                    .font(.custom("SF-Pro-Rounded", size: geometry.size.height*0.05))
                    .fontWeight(.heavy)
                    .foregroundColor(Color("purple title color"))
                    .padding(.top,  geometry.size.height*0.1)
                    .position(x: geometry.size.width*0.5, y: geometry.size.height*0.05)
                VStack{
                    ZStack{
                        VStack{
                            Image("wheel")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width*0.15)
                                .rotationEffect(Angle(degrees: isAnimated ? 360 : 0), anchor: .center)
                                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: isAnimated)
                                .onAppear(perform: {
                                     isAnimated = true
                                })
                        }
                        .position(x: geometry.size.width*0.5, y: geometry.size.height*0.6)
                        Image("shadow")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geometry.size.width*0.5)
                            .position(x: geometry.size.width*0.5, y: geometry.size.height*0.7)

                        
                        
                        Image("board")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geometry.size.width*0.55)
                            .position(x: geometry.size.width*0.5, y: geometry.size.height*0.5)
                        HStack{
                            Image("fuel 5 orange")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width*0.1)
                                .position(x: geometry.size.width*0.3, y: geometry.size.height*0.36)
                            Image("fuel 5 purple")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width*0.1)
                                .position(x: geometry.size.width*0.2, y: geometry.size.height*0.36)
                        }
                    }.offset(offset)
                        .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true), value: offset)
                        .onAppear {
                            offset = CGSize(width: 200, height: 0)
                        }
                        
                    Spacer()
                    
                    HStack{
                        NavigationLink(
                            destination: {
                                AnyView(PlayView())
                            }, label: {
                                Image("Restart")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width*0.23, height: geometry.size.height*0.2)
                                    
                            }
                        )
                        
                        
                        Button(action: {
                            isShowingAboutBattleOfTrust = true
                        }) {
                            Image("Button About the project")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width*0.20, height: geometry.size.height*0.12)
                                .padding(.leading, -70)
                        }
                    }.position(CGPoint(x: geometry.size.width*0.5, y: geometry.size.height*0.35))
                        .navigationBarTitle("")
                        .navigationBarHidden(true)
                        .navigationBarBackButtonHidden(true)
                }
                
                
                
                
            }
            if isShowingAboutBattleOfTrust{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    AboutBattleOfTrust(isShowing: $isShowingAboutBattleOfTrust)
                    
                }
            }
        }
        
    }
}

struct EndView_Previews: PreviewProvider {
    static var previews: some View {
        EndView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
