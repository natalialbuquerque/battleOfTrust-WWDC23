//
//  CityView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI

struct CityView: View {
    
    let texts = [
        "The Pit Stop is the only gas station in the\n small town of Trustland. Cournot is the\n owner of that company.",
        "For a long time the gas price at the station\n was $6 and the company's monthly profit\n $1800.",
        "However, John Nash became the owner of\n another gas station in the City,\n the Fuel Center.",
        "Now Cournot doesn't have as much\n freedom to choose the price, as his gas\n station prices now depend on Nash's\n station as well.",
        "Before Fuel Center opened, Cournot\n moved ahead to reach an agreement with\n Nash on the price of gasoline at both\n stations.",
        "Click on Fuel Center to meet Nash and\n have Cournot to strike a deal.",
        "After the agreement, Cournot noticed that\n the movement at his business had\n decreased a lot.",
        "Nash had not fulfilled the agreement.\n Fuel Center was priced at $5.\n Click on Fuel Center to meet Nash",
        "Despite the agreement reached,\n Cournot lost confidence in Nash.",
        "Help Cournot make a decision about what\n needs to be done. Click on Pit Stop to go\n to Cournot's office.",

    ]
    
    let imagesGasStation = [
        "Pit Stop",
        "fuel center",
    ]
    
    
    @State var currentTextIndex = 0
    @State private var count = 0
    
    @State private var isShowingNashRoom = false
    @State private var isShowingCournotRoomView = false
    
    @StateObject var nashRoomViewModel = NashRoomViewModel()
    @StateObject var cournotRoomViewModel = CournotRoomViewModel()
    
    @State private var shouldAnimate = false
    @State private var shouldAnimate1 = false
    @State private var shouldAnimate2 = false
    @State private var shouldAnimateBackground = false

    
    var body: some View {
        GeometryReader { geometry in
            
            Color("BackgroundCityView")
                .edgesIgnoringSafeArea(.all)
            
            if count <= 1 {
                Image("houses1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width*2)
                    .position(x: geometry.size.width*0.8, y: geometry.size.height*0.4)
                
                Image("trees")
                    .position(x: geometry.size.width*0.6, y: geometry.size.height*0.55)
            } else if count == 2 {
                Image("houses1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width*2)
                    .position(x: geometry.size.width*0.1, y: geometry.size.height*0.4)
                  
                
                Image("trees")
                    .position(x: geometry.size.width*0.1, y: geometry.size.height*0.55)
                   
            } else if count >= 3 {
                Image("houses1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width*2)
                    .position(x: geometry.size.width*0.1, y: geometry.size.height*0.4)
                
                Image("trees")
                    .position(x: geometry.size.width*0.1, y: geometry.size.height*0.55)
            }
            
    
            
            
            VStack{
                ZStack{
            
                    TextRectangle()
                    
                    Text(texts[currentTextIndex])
                        .font(.system(size: 30))
                        .multilineTextAlignment(.center)
                        .frame(height: 150)
                        .foregroundColor(.black)
                        
                    
                    
                    Button(action: {
                        self.currentTextIndex = (self.currentTextIndex + 1) % self.texts.count
                        count += 1
                    }) {
                        Image("button")
                    }
                    .padding(.bottom, -1200)
                    .padding(.leading, 700)
                    .opacity(count == 5 || count == 7 || count == 9 ? 0.0 : 1.0)
                }
                .padding(.top, 20)
                
                Spacer()
                
                HStack{
                    
                    if count <= 1 {
                        Image(imagesGasStation[0])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: geometry.size.height*0.55)
                            .offset(x: -geometry.size.width*0.3, y: geometry.size.height*0.012)
                        
                        
                    } else if count == 2 {
                        Image(imagesGasStation[1])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: geometry.size.height*0.55)
                            .offset(x: geometry.size.width*0.3, y: geometry.size.height*0.012)
                        
                    } else if count >= 3 && count < 5 || count == 6 || count == 8 || count >= 10 {
                        HStack{
                            Image(imagesGasStation[0])
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                            Spacer()
                            
                            Image(imagesGasStation[1])
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                        }
                        .frame(height: geometry.size.height*0.4)
                    } else if count == 5 {
                        HStack{
                            Image(imagesGasStation[0])
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                            
                            Spacer()
                            ZStack{
                                Image(imagesGasStation[1])
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.022)
                                    .blur(radius: 35.00)
                                    .scaleEffect(shouldAnimate ? 1.1 : 1.0)
                                    .animation(Animation.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: shouldAnimate)
                                    .onAppear() {
                                        self.shouldAnimate = true
                                        
                                    }
                                
                                Button(action: {
                                    self.currentTextIndex = (self.currentTextIndex + 1) % self.texts.count
                                    count += 1
                                    isShowingNashRoom = true
                                }) {
                                    Image(imagesGasStation[1])
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                                }
                                
                                
                            }
                            
                        }.frame(height: geometry.size.height*0.4)
                    } else if count == 7 {
                        HStack{
                            Image(imagesGasStation[0])
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                            
                            Spacer()
                            ZStack{
                                Image("Fuel Center price 5")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.022)
                                    .blur(radius: 35.00)
                                    .scaleEffect(shouldAnimate2 ? 1.1 : 1.0)
                                    .animation(Animation.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: shouldAnimate2)
                                    .onAppear() {
                                        self.shouldAnimate2 = true
                                        
                                    }
                                
                                Button(action: {
                                    self.currentTextIndex = (self.currentTextIndex + 1) % self.texts.count
                                    count += 1
                                    isShowingNashRoom = true
                                }) {
                                    Image("Fuel Center price 5")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                                }
                                
                                
                            }
                            
                        }.frame(height: geometry.size.height*0.4)
                    } else if count == 9  {
                        HStack{
                            ZStack{
                                Image(imagesGasStation[0])
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(x: -geometry.size.width*0.01, y: geometry.size.height*0.022)
                                    .blur(radius: 35.00)
                                    .scaleEffect(shouldAnimate1 ? 1.1 : 1.0)
                                    .animation(Animation.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: shouldAnimate1)
                                    .onAppear() {
                                        self.shouldAnimate1 = true

                                    }
                                
                                Button(action: {
                                    self.currentTextIndex = (self.currentTextIndex + 1) % self.texts.count
                                    count += 1
                                    isShowingCournotRoomView = true
                                }) {
                                    Image(imagesGasStation[0])
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                                }
                            }
                            
                            
                            Spacer()
                            
                            Image(imagesGasStation[1])
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                            
                        }.frame(height: geometry.size.height*0.4)
                    }
                    
                    
                }
                
                Image("street")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.bottom, -80)
            }
            
            if isShowingNashRoom{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    NashRoomView(isShowing: $isShowingNashRoom, viewModel: nashRoomViewModel)
                }
            }
            
            if isShowingCournotRoomView{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    CournotRoomView(viewModel: cournotRoomViewModel)
                }
            }
            
        }
        .navigationBarTitle("")
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}


struct CityView_Previews: PreviewProvider {
    static var previews: some View {
        CityView()
            .previewInterfaceOrientation(.landscapeLeft)
        
    }
}
