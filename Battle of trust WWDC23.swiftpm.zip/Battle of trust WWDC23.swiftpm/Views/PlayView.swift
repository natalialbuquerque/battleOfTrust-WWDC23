//
//  PlayView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI
// FOR A BETTER EXPERIENCE, USE THE APP ON LANDSCAPE. 
struct PlayView: View {
    
    @State private var isShowingHowToUse = false
    
    var body: some View {
        
        GeometryReader { geometry in
            NavigationView {
                ZStack{
                    Image("BackgroundPlayView")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .edgesIgnoringSafeArea(.all)
                    
                    
                    VStack {
                        Text("Battle of trust")
                            .font(.custom("SF-Pro-Rounded", size: geometry.size.height*0.15))
                            .fontWeight(.heavy)
                            .foregroundColor(Color("purple title color"))
                            .padding(.top,  geometry.size.height*0.1)
                        
                        
                        ZStack{
                            Image("fuels")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .edgesIgnoringSafeArea(.all)
                                .frame(height: geometry.size.height*0.5)
                                .position(x: geometry.size.width*0.5, y: geometry.size.height*0.4)
                            
                            
                            VStack{
                                HStack{
                                    NavigationLink(
                                        destination: {
                                            AnyView(CityView())
                                        }, label: {
                                            Image("start button")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .frame(width: geometry.size.width*0.20, height: geometry.size.height*0.2)
                                        }
                                    ).navigationBarTitle("")
                                        .navigationBarHidden(true)
                                        .navigationBarBackButtonHidden(true)
                                    
                                    
                                    
                                    Button(action: {
                                        isShowingHowToUse = true
                                    }) {
                                        Image("Buttom HowToUse")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: geometry.size.width*0.20, height: geometry.size.height*0.12)
                                            .padding(.leading, -70)
                                    }
                                    
                                    
                                }
                                .position(x: geometry.size.width*0.53, y: geometry.size.height*0.54)
                                
                                
                                
                                Text("""
                                     The story of how individuals behave in
                                     strategic situations.
                                     """)
                                .foregroundColor(Color("purple title color"))
                                .multilineTextAlignment(.center)
                                .font(.custom("Kreon-Regular", size: 30))
                                .position(x: geometry.size.width*0.5, y: geometry.size.height*0.3)
                            }// texto e botao
                            
                        }
                    } // fim da VStack
                }

            }.navigationViewStyle(.stack)
                
            
            
            if isShowingHowToUse{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    HowToUse(isShowing: $isShowingHowToUse)
                }
            }
        }
        .navigationBarTitle("")
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
       
        .onAppear{
            music(music: "soundWWDC")}
    }
}

struct PlayView_Previews: PreviewProvider {
    static var previews: some View {
        PlayView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
