//
//  CournotRoomView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI

class CournotRoomViewModel: ObservableObject {
    @Published var currentIndex = 0
    let texts = [
        "Let's think about the possibilities of values that\n Cournot can establish, considering the possible\n choices of Nash. Let's see in the notebook.",
        "Now help Cournot make a decision about these\n possibilities. Let's see in the notebook.",
    ]
    
}

struct CournotRoomView: View {

    @State private var count = 0
    @State private var isShowingDetailsCournotRoomView = false
    @State private var isShowingGameTheoryView = false
    @State private var shouldAnimate = false
    @State private var shouldAnimate1 = false
    
    @ObservedObject var viewModel: CournotRoomViewModel
    
    @StateObject var gameTheoryViewModel = GameTheoryViewModel()

    
    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("CournotRoomView Color")
                    .edgesIgnoringSafeArea(.all)
                
                Image("CournotRoomView1")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                    .position(x: geometry.size.width*0.55, y: geometry.size.height*0.5)
//                    .blur(radius: 3)
                VStack{
                    ZStack{
                        TextRectangle()
                        Text(viewModel.texts[viewModel.currentIndex])
                            .font(.system(size: 30))
                            .multilineTextAlignment(.center)
                            .frame(height: 150)
                            .foregroundColor(.black)
                   
                    }.padding(.top, 20)
                    
                        Spacer()
                        if viewModel.currentIndex == 0 {
                            Button(action: {
                                isShowingDetailsCournotRoomView = true
                                self.viewModel.currentIndex = (self.viewModel.currentIndex + 1) % self.viewModel.texts.count
                                
                            }) {
                                Image("notebook side")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: geometry.size.height*0.1)
                                    .padding(.bottom, shouldAnimate ? 200 : 100)
                                    .position(x: geometry.size.width*0.53, y: geometry.size.height*0.7)
                                    .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: shouldAnimate)
                                    .onAppear() {
                                        self.shouldAnimate = true
                                    }
                            }

                        } else  {
                            Button(action: {
                                isShowingGameTheoryView = true
                            }) {
                                Image("notebook side")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: geometry.size.height*0.1)
                                    .padding(.bottom, shouldAnimate1 ? 200 : 100)
                                    .position(x: geometry.size.width*0.53, y: geometry.size.height*0.7)
                                    .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: shouldAnimate1)
                                    .onAppear() {
                                        self.shouldAnimate1 = true
                                    }
                                  
                            }

                        }
                    
                }
                
            }
            
            
            
            
            
            
            
            
            
            
            if isShowingDetailsCournotRoomView{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    DetailsCournotRoomView(isShowing: $isShowingDetailsCournotRoomView)
                }
            }
            if isShowingGameTheoryView{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    GameTheoryView( viewModel: gameTheoryViewModel)
                }
            }

        }
        
    }
}

struct CournotRoomView_Previews: PreviewProvider {
    static var previews: some View {
        CournotRoomView(viewModel: CournotRoomViewModel())
            .previewInterfaceOrientation(.landscapeLeft)
        
    }
}
