//
//  CityViewLowerThePrice.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 13/04/23.
//

import SwiftUI

struct CityViewLowerThePrice: View {
    let textsLowerThePrice = [
        "Jeez! Both didn't keep their word and dropped the\n gas price to $5.",
        "The two Posts then took the profit of $800.",
        "This is not the best situation for both...",
        "But each firm wants to maximize its profits, and\n both are impacted by the other firm's pricing\n choices.",
        "It may happen that companies keep lowering\n prices, starting a price war.",
        "Until they reach the cost limits and thus,\n establishing a market equilibrium.",
    ]
    
    let imagesGasStation = [
        "Pit Stop",
        "fuel center",
    ]
    
    @State var currentTextIndex = 0
    @State private var isShowingEndView = false

    @State private var count = 0
    var body: some View {
        GeometryReader { geometry in
            Color("BackgroundCityView")
                .edgesIgnoringSafeArea(.all)
            
            Image("houses")
                .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.15)
            
            Image("trees")
                .offset(x: geometry.size.width*0.02, y: geometry.size.height*0.50)
            
            
            VStack {
                ZStack{
            
                    TextRectangle()
                    
                    Text(textsLowerThePrice[currentTextIndex])
                        .font(.system(size: 30))
                        .multilineTextAlignment(.center)
                        .frame(height: 150)
                        .foregroundColor(.black)
                    
                    
                    if count == 5 {
                        Button(action: {
                            self.currentTextIndex = (self.currentTextIndex + 1) % self.textsLowerThePrice.count
                            count += 1
                            isShowingEndView = true
                        }) {
                            Image("button")
                        }
                        .padding(.bottom, -1200)
                        .padding(.leading, 700)
                    } else {
                        Button(action: {
                            self.currentTextIndex = (self.currentTextIndex + 1) % self.textsLowerThePrice.count
                            count += 1
                        }) {
                            Image("button")
                        }
                        .padding(.bottom, -1200)
                        .padding(.leading, 700)
                    }
                }
                .padding(.top, 20)
                
                Spacer()
                HStack{
                    Image("Pit stop price 5")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                    Spacer()
                    
                    Image("Fuel Center price 5")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                }
                .frame(height: geometry.size.height*0.4)
                
                Image("street")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.bottom, -80)
            }
            if isShowingEndView{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    EndView()
                }
            }

            
        }
    }
}

struct CityViewLowerThePrice_Previews: PreviewProvider {
    static var previews: some View {
        CityViewLowerThePrice()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
