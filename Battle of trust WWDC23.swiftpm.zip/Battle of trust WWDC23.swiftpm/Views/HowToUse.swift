//
//  HowToUse.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 17/04/23.
//

import SwiftUI

struct HowToUse: View {
    @Binding var isShowing : Bool

    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("gameTheoryView color")
                    .edgesIgnoringSafeArea(.all)
                Image("notebook")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                VStack{
                    
                    Image("HowToUseImage")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: geometry.size.height*0.60)
                    
                    Button(action: {
                        isShowing = false
                    }) {
                        Image("button go back")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geometry.size.width*0.20, height: geometry.size.height*0.2)
                    }
                }
                
            }
        }
    }
}
struct HowToUse_Previews: PreviewProvider {
    static var previews: some View {
        PlayView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

