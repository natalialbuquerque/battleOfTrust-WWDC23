//
//  NashRoomView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI

class NashRoomViewModel: ObservableObject {
    @Published var currentIndex = 0
    let texts = [
        "The agreement consists of establishing the\n same price for both companies. Demand\n and profits would be shared equally.",
        "The price would be $6 for both companies.\n The monthly profit would be $900 for each.",
        "Nash agreed to the deal.",
        "Again, Cournot tries to strike\n the same deal with Nash.",
        "Nash agreed to the deal.",
    ]
}


struct NashRoomView: View {
    @Binding var isShowing : Bool
    @ObservedObject var viewModel: NashRoomViewModel
    
    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("NashRoomView Color")
                    .edgesIgnoringSafeArea(.all)
                Image("background books")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                    .blur(radius: 3)
                VStack{
                    ZStack{
                        TextRectangle()
                        
                        Text(viewModel.texts[viewModel.currentIndex])
                            .font(.system(size: 30))
                            .multilineTextAlignment(.center)
                            .frame(height: 150)
                            .foregroundColor(.black)
                        
                        if viewModel.currentIndex == 2 || viewModel.currentIndex == 4 {
                            Button(action: {
                                isShowing = false
                                self.viewModel.currentIndex = (self.viewModel.currentIndex + 1) % self.viewModel.texts.count
                           
                            }) {
                                Image("button")
                            }
                            .padding(.bottom, -1200)
                            .padding(.leading, 700)
                            
                        } else {
                            Button(action: {
                                self.viewModel.currentIndex = (self.viewModel.currentIndex + 1) % self.viewModel.texts.count
                                //                                viewModel.currentIndex += 1
                            }) {
                                Image("button")
                            }
                            .padding(.bottom, -1200)
                            .padding(.leading, 700)
                        }
                    }.padding(.top, 20)
                    
                    Spacer()
                    //                    HStack{
                    if viewModel.currentIndex == 2 || viewModel.currentIndex == 4 {
                        Image("deal")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .offset(y: -geometry.size.height*0.2)
                            .opacity(viewModel.currentIndex == 2 || viewModel.currentIndex == 4 ? 1.0 : 0.0)
                    } else {
                        HStack {
                            Image("Nash Room View 6")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                        }
                    }
                    
                    
                }
            }.navigationBarBackButtonHidden(true)
            
        }
        
    }
}


struct NashRoomView_Previews: PreviewProvider {
    static var previews: some View {
        PlayView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
