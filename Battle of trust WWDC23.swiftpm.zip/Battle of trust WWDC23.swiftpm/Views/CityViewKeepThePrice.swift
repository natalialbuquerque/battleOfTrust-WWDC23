//
//  CityViewKeepThePrice.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 13/04/23.
//

import SwiftUI

struct CityViewKeepThePrice: View {
    
    let textsKeepTheDeal = [
        "Ops! You chose to keep your word, but Nash\n didn't live up to his $5 price agreement\n with Cournot.",
        "Therefore, Cournot was left with a smaller share of\n the demand for gasoline and, consequently, with\n a much smaller profit than Nash.",
        "The truth is that in a situation like this, it is very\n difficult to maintain an agreement. That's because\n in the market, every company wants to\n maximize its profits.",
        "And once trust is lost after an agreement, a price\n war begins.",
        "The companies reduce the price of the product up\n to the limit, that depends on the costs of the\n companies.",
        "In this example, both companies would be priced\n at $5 and earnings of $800.",
        "Thus, market equilibrium would be reached,\n assuming that it is a duopoly and that companies\n have reached their cost limits."
    ]
    
    let imagesGasStation = [
        "Pit Stop",
        "fuel center",
    ]
    
    @State var currentTextIndex = 0
    @State private var isShowingEndView = false

    @State private var count = 0
    var body: some View {
        GeometryReader { geometry in
            Color("BackgroundCityView")
                .edgesIgnoringSafeArea(.all)
            
            Image("houses")
                .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.15)
            
            Image("trees")
                .offset(x: geometry.size.width*0.02, y: geometry.size.height*0.50)
   
            
            VStack {
                ZStack{
            
                    TextRectangle()
                    
                    Text(textsKeepTheDeal[currentTextIndex])
                        .font(.system(size: 30))
                        .multilineTextAlignment(.center)
                        .frame(height: 150)
                        .foregroundColor(.black)
                    
                    if count == 6 {
                        Button(action: {
                            self.currentTextIndex = (self.currentTextIndex + 1) % self.textsKeepTheDeal.count
                            count += 1
                            isShowingEndView = true 
                        }) {
                            Image("button")
                        }
                        .padding(.bottom, -1200)
                        .padding(.leading, 700)
                    } else {
                        Button(action: {
                            self.currentTextIndex = (self.currentTextIndex + 1) % self.textsKeepTheDeal.count
                            count += 1
                        }) {
                            Image("button")
                        }
                        .padding(.bottom, -1200)
                        .padding(.leading, 700)
                    }
                    
                }
                .padding(.top, 20)
                
                Spacer()
                HStack{
                    Image("Pit stop price 5")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .offset(x: -geometry.size.width*0.0, y: geometry.size.height*0.012)
                    Spacer()
                    
                    Image("Fuel Center price 5")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .offset(x: geometry.size.width*0.0, y: geometry.size.height*0.012)
                }
                .frame(height: geometry.size.height*0.4)
                
                Image("street")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.bottom, -80)
            }
            
            if isShowingEndView{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    EndView()
                }
            }
        }
        
    }
}

struct CityViewKeepThePrice_Previews: PreviewProvider {
    static var previews: some View {
        CityViewKeepThePrice()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
