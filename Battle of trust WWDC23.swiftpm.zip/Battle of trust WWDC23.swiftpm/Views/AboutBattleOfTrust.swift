//
//  AboutBattleOfTrust.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 17/04/23.
//

import SwiftUI

struct AboutBattleOfTrust: View {
    @Binding var isShowing : Bool
    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("gameTheoryView color")
                    .edgesIgnoringSafeArea(.all)
                
                Image("notebook")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                VStack{
                    ScrollView(.vertical) {
                                VStack {
                                    Text("          Economic science is present in everyone's life, determining how and with what quality we will all live. Understanding economic science, despite not being an easy task, helps people to make strategic and assertive decisions in various areas of life, especially business decisions.")
                                    Text("          I am excited to create a project that makes the economy more accessible. And for that to be possible, I assumed hypotheses to simplify the economic scenario. Here economic agents act rationally, the only differentiation of traded goods is the price and the only variables that influence the entire economic balance are the suppliers, demented, prices and profit.")
                                    Text("          Strategic decision-making helps entrepreneurs deal with market risks and uncertainties. And since the 1940s, Game Theory, an area of applied mathematics that studies strategic behavior and decision-making in interactive situations, has been used in economic science. This area of study allowed economists to analyze situations in which the decisions of an agent affect the decisions of other agents, and vice versa. This is what happens in a duopoly scenario featured in Battle of Trust.")
                                    Text("          In this project, the characters have their names chosen in honor of John Nash and Antoine Augustin Cournot. Nash was one of the most important mathematicians in the history of Game Theory. And one of his contributions was the formulation of the concept of Nash Equilibrium, the moment in the game in which no player has an incentive to change his strategy, given that the strategies of the other players remain unchanged. Cournot was also an important mathematician for the development of Game Theory, being responsible for developing one of the first mathematical models of oligopolistic competition.")
                                    Text("          It was a pleasure to transform a subject that I am passionate about and that is of great relevance into something playful and accessible to understand. I hope this project motivates other people to study Economic Science and Game Theory as well.")
                                    Text(" ")
                                    Text(" ")
                                    Text("Narrative, illustration and coding developed by Natália Pessôa de Azevedo Albuquerque.\nMusic Tango da Intriga https://elements.envato.com/pt-br/tango-of-intrigue-R3R77MC by scorewizards")
                                }
                            }.padding(.leading, geometry.size.height*0.3)
                        .padding(.trailing, geometry.size.height*0.33)
                        .padding(.top, geometry.size.height*0.08)
                        .font(.custom("SF-Pro-Rounded", size: geometry.size.height*0.032))
                        .foregroundColor(Color("purple title color"))
                    
                    
                    
                    Button(action: {
                        isShowing = false
                    }) {
                        Image("button go back")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geometry.size.width*0.20, height: geometry.size.height*0.2)
                    }
                }
                
            }
        }
    }
}

struct AboutBattleOfTrust_Previews: PreviewProvider {
    static var previews: some View {
        EndView()
            .previewInterfaceOrientation(.landscapeLeft)

    }
}
