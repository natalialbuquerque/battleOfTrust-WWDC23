//
//  DetailsCournotRoomView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI

struct DetailsCournotRoomView: View {
    
    let textsNotebook = ["notebook 1", "notebook 2", "notebook 3"]
    
    @State var currentTextIndex = 0
    @Binding var isShowing : Bool
    
    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("DetailsCournotRoomView Color")
                    .edgesIgnoringSafeArea(.all)
                
                Image(textsNotebook[currentTextIndex])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: geometry.size.height*0.75)
                    .offset(y: geometry.size.height*0.03)
                
                Image("3 pencils")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: geometry.size.height*0.45)
                    .offset(x: geometry.size.width*0.35 ,y: geometry.size.height*0.0)
                
                Image("glass")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: geometry.size.height*0.22)
                    .offset(x: geometry.size.width*0.4 ,y: -geometry.size.height*0.3)
                
                Image("lampshade 1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: geometry.size.height*0.45)
                    .offset(x: -geometry.size.width*0.4 ,y: -geometry.size.height*0.3)
                
                
                if currentTextIndex == 2 {
                    Button(action: {
                        isShowing = false
                        
                    }) {
                        Image("button")
                    }
                    .frame(height: geometry.size.height*0.45)
                    .offset(x: geometry.size.width*0.38 ,y: geometry.size.height*0.35)
                    
                } else {
                    Button(action: {
                        self.currentTextIndex = (self.currentTextIndex + 1) % self.textsNotebook.count
                    }) {
                        Image("button")
                    }
                    .frame(height: geometry.size.height*0.45)
                    .offset(x: geometry.size.width*0.38 ,y: geometry.size.height*0.35)
                }
                
                
                
            }
        }
    }
}
