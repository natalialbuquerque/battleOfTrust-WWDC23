//
//  GameTheoryView.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 02/04/23.
//

import SwiftUI

class GameTheoryViewModel: ObservableObject {
    @Published var currentTextIndex = 0
    let texts = [
        "Choose one of the options below to decide\n Cournot's profit, aiming for profit maximization\n and knowing that Nash can choose one of the\n options as well.",
        "You can still change your choice. Confirm your\n answer if you are sure.",
    ]
    
}

struct GameTheoryView: View {
    @State private var count = 0
    
    @State var isKeepTheDealOn = false
    @State var isLowerThePrice = false
    
    @State private var isShowingCityViewKeepThePrice = false
    @State private var isShowingCityViewLowerThePrice = false
    
    
    @ObservedObject var viewModel: GameTheoryViewModel
    
    var body: some View {
        GeometryReader { geometry in
            ZStack{
                Color("gameTheoryView color")
                    .edgesIgnoringSafeArea(.all)
                Image("notebook")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .offset(y: -geometry.size.height*0.03)
                VStack{
                    ZStack{
                        TextRectangle()
                        
                        Text(viewModel.texts[viewModel.currentTextIndex])
                            .font(.system(size: 30))
                            .multilineTextAlignment(.center)
                            .frame(height: 150)
                            .foregroundColor(.black)
                        
                        if viewModel.currentTextIndex >= 1 && isKeepTheDealOn == true{
                            Button(action: {
                                self.viewModel.currentTextIndex = (self.viewModel.currentTextIndex + 1) % self.viewModel.texts.count
                                count += 1
                                isShowingCityViewKeepThePrice = true
                            }) {
                                Image("button")
                            }
                            .padding(.bottom, -1200)
                            .padding(.leading, 700)
                        } else if viewModel.currentTextIndex >= 1 && isLowerThePrice == true{
                            Button(action: {
                                self.viewModel.currentTextIndex = (self.viewModel.currentTextIndex + 1) % self.viewModel.texts.count
                                count += 1
                                isShowingCityViewLowerThePrice = true
                            }) {
                                Image("button")
                            }
                            .padding(.bottom, -1200)
                            .padding(.leading, 700)
                        }
                        
                        
                    }
                    .padding(.top, 20)
                    
                    Spacer()
                    ZStack{
                        Image("game theory art")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: geometry.size.height*0.7)
                            .position(x: geometry.size.width*0.5, y: geometry.size.height*0.355)
                        
                        
                        
                        if isKeepTheDealOn == true {
                            Image("pencil circle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.6)
                                .position(x: geometry.size.width*0.5, y: geometry.size.height*0.45)
                            Image("color1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.09)
                                .position(x: geometry.size.width*0.55, y: geometry.size.height*0.3)
                            Image("color1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.08)
                                .position(x: geometry.size.width*0.55, y: geometry.size.height*0.5)
                        } else if isLowerThePrice == true {
                            Image("pencil circle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.6)
                                .position(x: geometry.size.width*0.7, y: geometry.size.height*0.45)
                            Image("color1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.09)
                                .position(x: geometry.size.width*0.74, y: geometry.size.height*0.3)
                            Image("color1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: geometry.size.height*0.08)
                                .position(x: geometry.size.width*0.74, y: geometry.size.height*0.5)
                        }
                        
                        
                        
                        
                        
                        HStack{
                            ZStack{
                                if isKeepTheDealOn == true {
                                    Image("keep the deal")
                                        .blur(radius: 35.00)
                                }
                                Button(action: {
                                    isKeepTheDealOn = true
                                    isLowerThePrice = false
                                    viewModel.currentTextIndex = 1
                                    count += 1
                                }) {
                                    Image("keep the deal")
                                    
                                }
                            }
                            ZStack{
                                if isLowerThePrice == true {
                                    Image("lower the price")
                                        .blur(radius: 35.00)
                                }
                                
                                Button(action: {
                                    count += 1
                                    viewModel.currentTextIndex = 1
                                    isKeepTheDealOn = false
                                    isLowerThePrice = true
                                }) {
                                    Image("lower the price")
                                    
                                }
                            }
                            
                            
                            
                        }
                        .position(x: geometry.size.width*0.6, y: geometry.size.height*0.17)


         
                        
                    }
                    
                }
                
            }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            if isShowingCityViewKeepThePrice{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    CityViewKeepThePrice()
                }
            }
            
            if isShowingCityViewLowerThePrice{
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
                    
                    CityViewLowerThePrice()
                }
            }
        }
    }
}

//struct GameTheoryView_Previews: PreviewProvider {
//    static var previews: some View {
//        GameTheoryView( viewModel: gameTheoryViewModel)
//            .previewInterfaceOrientation(.landscapeLeft)
//
//    }
//}
struct GameTheoryView_Previews: PreviewProvider {
    static var previews: some View {
        CournotRoomView(viewModel: CournotRoomViewModel())
            .previewInterfaceOrientation(.landscapeLeft)
        
    }
}
