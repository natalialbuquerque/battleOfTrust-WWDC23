//
//  TextRectangle.swift
//  Battle of trust WWDC23
//
//  Created by Natália Pessoa de Azevedo Albuquerque on 13/04/23.
//

import SwiftUI

struct TextRectangle: View {
    var body: some View {
        Image("Rectangle")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: 200)
            .padding(.top, 10)
    }
}

